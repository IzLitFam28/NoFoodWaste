import streamlit as st

st.write(f'Welcome *{st.session_state["name"]}*')