CHEF_NAME = """
    <div class ="choose_chef">Choose chef:</div>
""".strip()

CUISINE = """
    <div class ="cuisine">Examples (select from this list):</div>
""".strip()

INGREDIENTS = """
    <div class ="ingredients_to_recipe">Insert your food items here (separated by `,`): </div>
""".strip()