HEADER_INFO = """""".strip()

CHEF_INFO = """
<div class="body">
        <p>What Ingredients do you have today?</p>
    </div>
""".strip()
PROMPT_BOX = "Add custom ingredients here (separated by `,`): "



