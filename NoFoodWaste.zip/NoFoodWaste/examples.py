EXAMPLES = {
    "Turkish Food 1": "phyllo dough, unsalted butter, walnuts, cinnamon, water, honey, melted chocolate",
    "Persian Food 1": "beef, oil, onion, tomatoes, turmeric powder, limes, water, salt, pepper, red beans, herb",
    "Persian Food 2": "beef, potatoes, eggs, onion, flour, turmeric powder, oil, salt, pepper",
    "Persian Food 3": "walnut pieces, onion, boneless skinless chicken thighs, pomegranate molasses, orange juice, chicken stock, cinnamon, salt, pepper, oil",
    "Turkish Food 2": "water, dry active yeast, flour, salt, olive oil, ground beef, onion, pepper, salt, feta cheese, parsley, lemon",
    "Korean Food 1": "pork chops, soy sauce, honey, garlic, sesame oil, fresh ginger root, sweet chili sauce, olive oil",
    "Italian Food 1": "rotini pasta, broccoli florets, parmesan cheese, red pepper, onions, black olives",
    "German Food 1": "oil, boneless pork chops, salt, pepper, flour, eggs, breadcrumbs, gravy, parsley"
}
